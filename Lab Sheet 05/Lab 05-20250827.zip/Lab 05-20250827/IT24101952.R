setwd("C:/Users/it24101952/Downloads/Lab 05-20250827")

d<-read.table("Exercise - Lab 05.txt",header = TRUE,sep =",")

fix(d)

c<-read.table("Data.txt",header=TRUE,sep = ",")

delivery_time<-d

fix(delivery_time)

names(delivery_time)<-c("X1")

attach(delivery_time)

histrogram<-hist(X1,main = "Histrogram for delivery_time",breaks = seq(20,70, length(7)))

breaks<-round(histrogram$breaks)

breaks

freq<-histrogram$counts

mids<-histrogram$mids

classes<-c()

for (i in 1:length(breaks)-1) {
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")"),
}

cbind(Classes=classes,Frequency=freq)

lines(mids,freq)

plot(mids,freq,type = 'l',main = "Frequency Polygon gor delivery_time",xlab = "delivery_time",ylab = "frequency",ylim = c(0,max(freq)))

cum.freq<-cumsum(freq)
new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type='l',main = "cumalative Frequency polygon for delivery_time",
     xlab="Delivery_time",ylab="cumalative Frequency",ylim=c(0,max(cum.freq)))

cbind(Upper=breaks,Cumfreq=new)

